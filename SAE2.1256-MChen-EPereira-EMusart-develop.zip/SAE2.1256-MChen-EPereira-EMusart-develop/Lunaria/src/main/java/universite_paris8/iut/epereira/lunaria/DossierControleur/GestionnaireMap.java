package universite_paris8.iut.epereira.lunaria.DossierControleur;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.TilePane;
import universite_paris8.iut.epereira.lunaria.modele.Terrain;

public class GestionnaireMap {
    private Terrain carte;
    private TilePane panneauDeTuile;
    private Image image;
    ImageView vue;

    public GestionnaireMap(TilePane panneauDeTuile, Terrain carte) {
        this.carte = carte;
        this.panneauDeTuile = panneauDeTuile;
        this.image = null;
        this.vue = null;
    }

    public void chargerTiles(Terrain terrain) {

        if (panneauDeTuile == null || terrain == null || terrain.getTerrain() == null) {
            System.err.println("Erreur: panneauDeTuile ou terrain est null");
            return;
        }

        panneauDeTuile.getChildren().clear();

        int[][] mapData = terrain.getTerrain();

        System.out.println("Dimensions du terrain: " + terrain.getWidth() + "x" + terrain.getHeight());

        for (int i = 0; i < terrain.getHeight(); i++) {
            for (int j = 0; j < terrain.getWidth(); j++) {
                try {
                    int tile = mapData[i][j];
                    Image sprite;

                    if (tile == 0)
                        sprite = new Image(getClass().getResourceAsStream("/universite_paris8/iut/epereira/lunaria/DossierMap/Ciel.png"));
                     else if (tile ==1)
                        sprite = new Image(getClass().getResourceAsStream("/universite_paris8/iut/epereira/lunaria/DossierMap/Terre.png"));
                     else if (tile ==2)
                        sprite = new Image(getClass().getResourceAsStream("/universite_paris8/iut/epereira/lunaria/DossierMap/Herbe.png"));
                     else
                        sprite = new Image(getClass().getResourceAsStream("/universite_paris8/iut/epereira/lunaria/DossierMap/Buisson.png"));

                    ImageView imageView = new ImageView(sprite);
                    imageView.setFitHeight(32);
                    imageView.setFitWidth(32);

                    panneauDeTuile.getChildren().add(imageView);

                } catch (Exception e) {
                    System.out.println("Erreur lors du chargement de la tuile [" + i + "," + j + "]: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }

    public Terrain getCarte() {
        return carte;
    }
}